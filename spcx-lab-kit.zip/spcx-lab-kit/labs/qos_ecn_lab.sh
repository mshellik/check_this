#!/usr/bin/env bash
# Lab 5/6 — RoCE QoS classes + ECN congestion marking on a Linux "switch".
# Mirrors the Cumulus "nv set qos roce" defaults:
#   DSCP 26 -> switch-prio 3 -> TC3 (RoCE)  DWRR 50%, ECN marking
#   DSCP 48 -> switch-prio 6 -> TC6 (CNP)   strict priority
#   everything else -> TC0                   DWRR 50%
# Topology:  s1,s2,s3 --> [sw] --(1 Gbit/s bottleneck)--> rx
# Usage: sudo ./qos_ecn_lab.sh up | run [ecn|noecn] | stats | down
set -euo pipefail
NS="s1 s2 s3 sw rx"
BOTTLENECK=${BOTTLENECK:-1gbit}
x() { ip netns exec "$@"; }

up() {
  for n in $NS; do ip netns del $n 2>/dev/null || true; ip netns add $n; x $n ip link set lo up; done
  i=1
  for s in s1 s2 s3; do
    ip link add $s-eth0 type veth peer name sw-p$i
    ip link set $s-eth0 netns $s; ip link set sw-p$i netns sw
    x $s ip addr add 192.168.$i.2/24 dev $s-eth0; x $s ip link set $s-eth0 up
    x $s ip route add default via 192.168.$i.1
    x sw ip addr add 192.168.$i.1/24 dev sw-p$i; x sw ip link set sw-p$i up
    i=$((i+1))
  done
  ip link add sw-up type veth peer name rx-eth0
  ip link set sw-up netns sw; ip link set rx-eth0 netns rx
  x sw ip addr add 192.168.100.1/24 dev sw-up; x sw ip link set sw-up up
  x rx ip addr add 192.168.100.2/24 dev rx-eth0; x rx ip link set rx-eth0 up
  x rx ip route add default via 192.168.100.1
  x sw sysctl -qw net.ipv4.ip_forward=1
  qos
  for p in 5201 5202 5203; do x rx iperf3 -s -p $p -D; done
  echo "lab up. next: sudo $0 run ecn"
}

qos() {   # the "switch QoS policy" on the egress port toward rx
  D=sw-up
  x sw tc qdisc del dev $D root 2>/dev/null || true
  x sw tc qdisc add dev $D root handle 1: htb default 10 r2q 1000
  x sw tc class add dev $D parent 1:  classid 1:1  htb rate $BOTTLENECK
  x sw tc class add dev $D parent 1:1 classid 1:6  htb rate 50mbit  ceil $BOTTLENECK prio 0   # TC6 CNP (strict)
  x sw tc class add dev $D parent 1:1 classid 1:3  htb rate 475mbit ceil $BOTTLENECK prio 1   # TC3 RoCE 50%
  x sw tc class add dev $D parent 1:1 classid 1:10 htb rate 475mbit ceil $BOTTLENECK prio 1   # TC0 other 50%
  # ECN/RED on the RoCE class (Spectrum: ECN absolute threshold on TC3); taildrop elsewhere
  if ! x sw tc qdisc add dev $D parent 1:3 handle 30: red limit 4000000 min 150000 max 1500000 \
       avpkt 1500 burst 200 probability 1.0 bandwidth $BOTTLENECK ${ECN_FLAG-ecn} 2>/dev/null; then
    echo "WARN: kernel lacks sch_red (CONFIG_NET_SCH_RED); TC3 falls back to taildrop — no ECN marks." >&2
    x sw tc qdisc add dev $D parent 1:3 handle 30: pfifo limit 1000
  fi
  x sw tc qdisc add dev $D parent 1:10 handle 100: pfifo limit 1000
  x sw tc qdisc add dev $D parent 1:6  handle 60: pfifo limit 100
  # trust DSCP: classify on the 6 DSCP bits (mask 0xfc)
  x sw tc filter add dev $D parent 1: protocol ip prio 1 u32 match ip dsfield 0x68 0xfc flowid 1:3  # DSCP 26
  x sw tc filter add dev $D parent 1: protocol ip prio 1 u32 match ip dsfield 0xc0 0xfc flowid 1:6  # DSCP 48
}

run() {
  mode=${1:-ecn}
  if [ "$mode" = noecn ]; then ECN_FLAG=""; ecn=0; else ECN_FLAG="ecn"; ecn=1; fi
  export ECN_FLAG; qos
  for s in s1 s2; do x $s sysctl -qw net.ipv4.tcp_ecn=$ecn; done
  echo "== mode=$mode: s1+s2 'RoCE' flows (DSCP 26) incast into TC3, s3 'CNP' (DSCP 48), 10s"
  x s1 iperf3 -c 192.168.100.2 -p 5201 -S 0x68 -P 4 -t 10 -J > /tmp/s1.json &
  x s2 iperf3 -c 192.168.100.2 -p 5202 -S ${S2TOS:-0x68} -P 4 -t 10 -J > /tmp/s2.json &
  x s3 iperf3 -c 192.168.100.2 -p 5203 -S 0xc0 -u -b 20M -t 10 -J > /tmp/s3.json &
  wait
  python3 - <<'EOF'
import json
for f, name in (("/tmp/s1.json","s1 RoCE(TC3)"),("/tmp/s2.json","s2 (S2TOS)"),("/tmp/s3.json","s3 CNP (TC6)")):
    j = json.load(open(f))["end"]
    s = j.get("sum_sent") or j.get("sum")
    print(f"  {name:14} {s['bits_per_second']/1e6:8.1f} Mb/s  retransmits={s.get('retransmits','-')}  "
          f"lost={j.get('sum',{}).get('lost_percent','-')}")
EOF
  stats
}

stats() {
  echo "== TC3 (RoCE) RED/ECN qdisc:"; x sw tc -s qdisc show dev sw-up parent 1:3 | sed 's/^/   /'
  echo "== per-class bytes:"; x sw tc -s class show dev sw-up | grep -E "class htb|Sent" | paste - - | \
     awk '{print "   "$3, $NF=="" ? "" : "", $0}' | sed -E 's/ +rate.*Sent/ Sent/' | cut -c1-110
}

down() { for n in $NS; do ip netns pids $n 2>/dev/null | xargs -r kill; ip netns del $n 2>/dev/null || true; done; echo down; }

"${1:-up}" "${@:2}"
