#!/usr/bin/env bash
# Lab 4 (host side) — Soft-RoCE: real RDMA verbs over an ordinary Ethernet NIC, no NVIDIA hardware.
# Run on TWO Linux VMs on the same L2/L3 network (Ubuntu 22.04/24.04). Usage:
#   sudo ./host_roce_lab.sh setup <netdev>            e.g. setup ens3
#   sudo ./host_roce_lab.sh server                    on VM-A
#   sudo ./host_roce_lab.sh client <server-ip>        on VM-B
#   sudo ./host_roce_lab.sh capture <netdev>          watch RoCEv2 on the wire (UDP 4791, DSCP)
set -euo pipefail
TCLASS=${TCLASS:-106}   # 106 = DSCP 26 (<<2 = 104) + ECT(0) bits (2): what Spectrum-X hosts send
case "${1:-}" in
  setup)
    apt-get install -y rdma-core ibverbs-utils perftest tcpdump >/dev/null
    modprobe rdma_rxe
    rdma link add rxe0 type rxe netdev "$2" 2>/dev/null || true
    rdma link show; ibv_devices
    echo "GID table (index 1 is usually RoCEv2/IPv4):"; ibv_devinfo -v -d rxe0 | grep -E "GID\[" ;;
  server) ib_write_bw -d rxe0 -x "${GID:-1}" --report_gbits --tclass="$TCLASS" ;;
  client) ib_write_bw -d rxe0 -x "${GID:-1}" --report_gbits --tclass="$TCLASS" "$2" ;;
  capture) tcpdump -i "$2" -nn -v -c 20 udp port 4791 ;;
  *) sed -n '2,9p' "$0" ;;
esac
