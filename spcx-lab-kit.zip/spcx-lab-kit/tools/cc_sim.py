#!/usr/bin/env python3
"""
cc_sim.py — incast congestion: no control vs. PFC vs. ECN/DCQCN-style vs. Spectrum-X-style.

Teaching model. N senders at line rate converge on ONE egress port (classic all-to-one incast).
Time step = 1 microsecond.

  lossy    : no congestion control, tail-drop when the buffer is full  -> drops / retransmits
  pfc      : lossless, switch pauses upstream when the queue crosses XOFF -> no drops, but
             pause spreads upstream (head-of-line blocking of innocent "victim" traffic)
  ecn      : DCQCN-like. Switch ECN-marks above Kmin; receiver NIC returns CNPs; sender NIC cuts
             rate multiplicatively after a feedback delay, then recovers additively.
  spcx     : Spectrum-X-like. Switch telemetry reaches the SuperNIC sooner and carries how
             congested the port is, so senders move straight toward their fair share.

Usage: ./cc_sim.py [--senders 8] [--gbps 400] [--buffer-mb 16] [--us 400] [--mode all]
"""
import argparse

def simulate(mode, n, gbps, buf_bytes, us, kmin, xoff, fb_delay):
    cap = gbps * 1e9 / 8 / 1e6          # bytes per microsecond the port can drain
    rate = [cap] * n                     # each sender starts at line rate
    q = drops = paused_us = 0.0
    hist, pending = [], []               # pending feedback: (deliver_time, severity)
    pause = False
    for t in range(us):
        offered = 0.0 if pause else sum(rate)
        served = min(q + offered, cap)
        q += offered - served
        q = max(q, 0.0)
        if mode == "lossy" and q > buf_bytes:
            drops += q - buf_bytes; q = buf_bytes
        if mode == "pfc":
            if q > xoff: pause = True
            elif q < xoff * 0.5: pause = False
            paused_us += pause
        if mode in ("ecn", "spcx") and q > kmin:
            sev = min(1.0, (q - kmin) / (buf_bytes * 0.25))
            pending.append((t + fb_delay, sev))
        if mode in ("ecn", "spcx"):
            arrived = [s for (d, s) in pending if d == t]
            pending = [(d, s) for (d, s) in pending if d > t]
            for i in range(n):
                if arrived and mode == "ecn":
                    rate[i] *= 1 - 0.5 * max(0.3, max(arrived))       # multiplicative decrease
                elif arrived and mode == "spcx":
                    fair = cap / n
                    rate[i] = rate[i] - (rate[i] - fair * (1 - 0.2 * max(arrived))) * 0.8
                else:
                    rate[i] = min(cap, rate[i] + cap * (0.002 if mode == "ecn" else 0.004))  # additive increase
        hist.append((t, q, served / cap))
    return hist, drops, paused_us

def jain(x):
    return sum(x) ** 2 / (len(x) * sum(v * v for v in x)) if any(x) else 0

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--senders", type=int, default=8)
    ap.add_argument("--gbps", type=float, default=400)
    ap.add_argument("--buffer-mb", type=float, default=16)
    ap.add_argument("--us", type=int, default=400)
    ap.add_argument("--mode", default="all", choices=["all", "lossy", "pfc", "ecn", "spcx"])
    a = ap.parse_args()
    buf = a.buffer_mb * 1e6
    modes = ["lossy", "pfc", "ecn", "spcx"] if a.mode == "all" else [a.mode]
    print(f"\nIncast: {a.senders} senders x {a.gbps:.0f}G -> one {a.gbps:.0f}G port, "
          f"{a.buffer_mb:g} MB buffer, {a.us} us\n")
    print(f"  {'mode':6} {'peak queue':>11} {'avg queue':>10} {'dropped':>9} {'paused':>8} {'util':>5}  queue over time (each char = {a.us//40} us)")
    for m in modes:
        hist, drops, paused = simulate(m, a.senders, a.gbps, buf, a.us,
                                       kmin=buf * 0.01, xoff=buf * 0.6,
                                       fb_delay=8 if m == "ecn" else 3)
        qs = [h[1] for h in hist]
        step = max(1, a.us // 40)
        spark = "".join(" .:-=+*#%@"[min(9, int(qs[i] / buf * 9.99))] for i in range(0, a.us, step))
        print(f"  {m:6} {max(qs)/1e6:9.2f}MB {sum(qs)/len(qs)/1e6:8.2f}MB "
              f"{drops/1e6:7.1f}MB {paused:6.0f}us {sum(h[2] for h in hist)/len(hist)*100:4.0f}%  |{spark}|")
    print("""
  Read it like this:
   lossy : the buffer fills in microseconds and the rest is dropped -> RoCE go-back-N retransmits.
   pfc   : no drops, but the port spends much of the time PAUSED; anything else behind the
           paused upstream port also stops (head-of-line blocking, pause storms).
   ecn   : no drops, but the late feedback and blunt rate cuts overshoot: the queue empties and
           the port sits partly idle (lower util) before senders creep back up.
   spcx  : earlier, richer signal -> senders land near fair share: shallow queue AND a busy port.
  Spectrum-X uses PFC only as a safety net; congestion control does the real work.
""")

if __name__ == "__main__":
    main()
