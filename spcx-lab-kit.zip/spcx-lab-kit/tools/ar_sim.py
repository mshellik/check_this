#!/usr/bin/env python3
"""
ar_sim.py — why static ECMP hurts AI collectives and what adaptive routing fixes.

Teaching model (not an ASIC emulator). A leaf has K uplinks of equal speed.
F elephant flows (one per GPU/NIC in an all-reduce step) each carry the same bytes.
The collective step finishes only when the SLOWEST flow finishes (job completion time, JCT).

  ecmp     : each flow is hashed once onto one uplink (5-tuple hash). Collisions share a link.
  flowlet  : flows are re-hashed at idle gaps; modelled as R re-hash opportunities per flow.
  adaptive : Spectrum-X style per-packet spraying to the least-loaded uplink; the SuperNIC
             puts out-of-order packets back in place (Direct Data Placement), so every flow
             sees the aggregate bandwidth.

Usage: ./ar_sim.py [--uplinks 8] [--flows 8] [--gbps 400] [--gb 1] [--trials 1000] [--seed 7]
"""
import argparse, random, statistics

def jct_static(assign, k, size_gbit, gbps):
    """Water-filling: links share capacity among their active flows; recompute as flows finish."""
    remaining = {f: size_gbit for f in range(len(assign))}
    t = 0.0
    while remaining:
        per_link = [0] * k
        for f in remaining: per_link[assign[f]] += 1
        rates = {f: gbps / per_link[assign[f]] for f in remaining}
        dt = min(remaining[f] / rates[f] for f in remaining)
        t += dt
        for f in list(remaining):
            remaining[f] -= rates[f] * dt
            if remaining[f] <= 1e-9: del remaining[f]
    return t

def ecmp(k, f, rng):
    return [rng.randrange(k) for _ in range(f)]

def flowlet(k, f, rng, rehash=4):
    """Best of a few re-hash chances (greedy toward least-loaded at each flowlet boundary)."""
    load = [0] * k
    assign = []
    for _ in range(f):
        choices = [rng.randrange(k) for _ in range(rehash)]
        c = min(choices, key=lambda x: load[x]); load[c] += 1; assign.append(c)
    return assign

def bar(n, scale=1):
    return "#" * int(n * scale)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--uplinks", type=int, default=8)
    ap.add_argument("--flows", type=int, default=8)
    ap.add_argument("--gbps", type=float, default=400)
    ap.add_argument("--gb", type=float, default=1.0, help="GBytes per flow")
    ap.add_argument("--trials", type=int, default=1000)
    ap.add_argument("--seed", type=int, default=7)
    a = ap.parse_args()
    rng = random.Random(a.seed)
    size = a.gb * 8  # Gbit
    ideal = size * a.flows / (a.uplinks * a.gbps)

    # one illustrated trial
    sample = ecmp(a.uplinks, a.flows, rng)
    print(f"\nOne ECMP hash outcome: {a.flows} flows onto {a.uplinks} x {a.gbps:.0f}G uplinks")
    for l in range(a.uplinks):
        n = sample.count(l)
        print(f"  uplink{l}: {bar(n, 4):<16} {n} flow(s){'  <- collision' if n > 1 else ('  <- idle' if n == 0 else '')}")

    res = {"ecmp": [], "flowlet": [], "adaptive": []}
    for _ in range(a.trials):
        res["ecmp"].append(jct_static(ecmp(a.uplinks, a.flows, rng), a.uplinks, size, a.gbps))
        res["flowlet"].append(jct_static(flowlet(a.uplinks, a.flows, rng), a.uplinks, size, a.gbps))
        res["adaptive"].append(ideal)  # packet spraying = perfect share of aggregate bandwidth

    print(f"\nJob completion time for one all-reduce step ({a.gb:g} GB per flow, {a.trials} trials)")
    print(f"  {'mode':9} {'mean ms':>8} {'p99 ms':>8} {'worst ms':>9} {'eff. BW':>8}")
    for m, v in res.items():
        v = sorted(v); p99 = v[int(0.99 * (len(v) - 1))]
        print(f"  {m:9} {statistics.mean(v)*1e3:8.2f} {p99*1e3:8.2f} {v[-1]*1e3:9.2f} "
              f"{ideal / statistics.mean(v) * 100:7.0f}%")
    gain = statistics.mean(res["ecmp"]) / ideal
    print(f"\n  Adaptive routing finishes the step {gain:.2f}x faster than static ECMP on average.")
    print("  Talking point: GPUs idle while waiting for the slowest flow — that idle time is what")
    print("  Spectrum-X buys back. (NVIDIA quotes ~1.6x AI network performance vs. traditional Ethernet.)\n")

if __name__ == "__main__":
    main()
