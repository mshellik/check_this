# Spectrum-X Lab Kit (NVIDIA Air substitute)

Companion to *Spectrum-X Networking Platform Administration — Trainer Guide & Simulation Labs*.

## Requirements
Ubuntu 22.04/24.04 VM (bare-metal or cloud), 4 vCPU, 8 GB RAM, root access.

```bash
sudo apt update && sudo apt install -y frr iperf3 iputils-ping traceroute python3-yaml \
     rdma-core ibverbs-utils perftest tcpdump
pip install --break-system-packages opentelemetry-sdk opentelemetry-exporter-otlp-proto-grpc
sudo systemctl disable --now frr      # spcx starts its own FRR instances per switch
```

## Layout
| Path | Purpose | Labs |
|---|---|---|
| `topology.yaml` | the digital twin: nodes, ASNs, loopbacks, cabling, IP plan | 0 |
| `spcx.py` | build / operate / validate / break the fabric | 0-3, 8, 9 |
| `configs/`, `clab/` | generated FRR configs + containerlab topology (`./spcx.py gen`) | 1 |
| `labs/host_roce_lab.sh` | Soft-RoCE + perftest + wire capture between two VMs | 4 |
| `labs/qos_ecn_lab.sh` | DSCP trust, TC3/TC6 ETS scheduling, ECN marking under incast | 5 |
| `tools/cc_sim.py` | incast model: lossy vs PFC vs ECN vs Spectrum-X-style CC | 5 |
| `tools/ar_sim.py` | static ECMP vs flowlet vs adaptive routing, job completion time | 6 |
| `telemetry/` | OTLP emitter + OpenTelemetry Collector + Prometheus + Grafana | 7 |

## Quick start
```bash
sudo ./spcx.py up                 # netns runtime (default)
sudo ./spcx.py check all
sudo ./spcx.py vtysh leaf1        # interactive switch CLI
sudo ./spcx.py break list         # troubleshooting scenarios
sudo ./spcx.py down
```
containerlab instead of netns: `sudo ./spcx.py up --runtime clab` (needs Docker + containerlab and
the `frrouting/frr:v8.4.0` image).
Kernels without IPv6 fall back automatically to numbered /31 fabric links; force either mode with
`SPCX_ADDRESSING=unnumbered|numbered`.
