#!/usr/bin/env python3
"""
otlp_switch_emitter.py — stands in for "nv set system telemetry export otlp ..." on a Spectrum switch.

Pushes switch-style metrics over OTLP/gRPC to an OpenTelemetry Collector (default localhost:4317),
exactly the path a Spectrum-X switch or DOCA Telemetry Service (DTS) uses.

  --source lab   real interface counters read from the spcx fabric (netns runtime) + modelled ASIC
                 counters (ECN marks, PFC pauses, buffer occupancy, adaptive-routing changes)
  --source synth fully synthetic switches (no fabric needed)
  --console      print metrics to stdout instead of exporting (no collector needed)
  --hotspot leaf3:eth1   make one port congested so the dashboard has something to find

pip install opentelemetry-sdk opentelemetry-exporter-otlp-proto-grpc
"""
import argparse, json, random, subprocess, time
from opentelemetry import metrics
from opentelemetry.metrics import Observation
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader, ConsoleMetricExporter
from opentelemetry.sdk.resources import Resource

SW = {"spine1": ["eth1", "eth2", "eth3", "eth4"], "spine2": ["eth1", "eth2", "eth3", "eth4"],
      "leaf1": ["eth1", "eth2", "eth3", "eth4"], "leaf2": ["eth1", "eth2", "eth3", "eth4"],
      "leaf3": ["eth1", "eth2", "eth3", "eth4"], "leaf4": ["eth1", "eth2", "eth3", "eth4"]}

class Model:
    def __init__(self, source, hotspot):
        self.source, self.hot = source, hotspot
        self.c = {}            # cumulative counters per (sw, port, name)

    def lab_counters(self, sw):
        try:
            out = subprocess.run(["ip", "netns", "exec", sw, "ip", "-j", "-s", "link"],
                                 capture_output=True, text=True, timeout=3).stdout
            return {i["ifname"]: i["stats64"] for i in json.loads(out)}
        except Exception:
            return {}

    def tick(self):
        rows = []
        for sw, ports in SW.items():
            real = self.lab_counters(sw) if self.source == "lab" else {}
            for p in ports:
                hot = self.hot == f"{sw}:{p}"
                k = (sw, p)
                st = self.c.setdefault(k, {"rx": 0, "tx": 0, "ecn": 0, "pfc": 0, "ar": 0})
                if p in real:
                    st["rx"], st["tx"] = real[p]["rx"]["bytes"], real[p]["tx"]["bytes"]
                else:
                    st["rx"] += random.randint(2, 6) * 10**9; st["tx"] += random.randint(2, 6) * 10**9
                st["ecn"] += random.randint(20000, 80000) if hot else random.randint(0, 40)
                st["pfc"] += random.randint(200, 900) if hot else (1 if random.random() < 0.02 else 0)
                st["ar"] += random.randint(50, 400)
                buf = random.uniform(0.55, 0.9) if hot else random.uniform(0.0, 0.08)
                rows.append((sw, p, dict(st), buf))
        self.rows = rows
        return rows

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--endpoint", default="localhost:4317")
    ap.add_argument("--source", choices=["lab", "synth"], default="synth")
    ap.add_argument("--interval", type=float, default=5)
    ap.add_argument("--hotspot", default="leaf3:eth1")
    ap.add_argument("--console", action="store_true")
    ap.add_argument("--count", type=int, default=0, help="stop after N exports (0 = forever)")
    a = ap.parse_args()

    if a.console:
        exporter = ConsoleMetricExporter()
    else:
        from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import OTLPMetricExporter
        exporter = OTLPMetricExporter(endpoint=a.endpoint, insecure=True)
    reader = PeriodicExportingMetricReader(exporter, export_interval_millis=int(a.interval * 1000))
    metrics.set_meter_provider(MeterProvider(resource=Resource.create(
        {"service.name": "spcx-switch-telemetry", "net.fabric": "spcx-lab"}), metric_readers=[reader]))
    meter = metrics.get_meter("spcx.switch")
    m = Model(a.source, a.hotspot)
    m.tick()

    def obs(key, scale=1):
        def cb(_):
            return [Observation(st[key] * scale, {"switch": sw, "interface": p}) for sw, p, st, _ in m.rows]
        return cb

    meter.create_observable_counter("spcx_interface_rx_bytes", [obs("rx")], unit="By")
    meter.create_observable_counter("spcx_interface_tx_bytes", [obs("tx")], unit="By")
    meter.create_observable_counter("spcx_tc3_ecn_marked_packets", [obs("ecn")], unit="{packet}",
                                    description="RoCE traffic-class packets ECN-marked by the ASIC")
    meter.create_observable_counter("spcx_prio3_pfc_pause_rx", [obs("pfc")], unit="{frame}",
                                    description="PFC pause frames received on switch-priority 3")
    meter.create_observable_counter("spcx_adaptive_routing_changes", [obs("ar")], unit="{event}")
    meter.create_observable_gauge("spcx_egress_buffer_occupancy_ratio",
        [lambda _: [Observation(b, {"switch": sw, "interface": p, "traffic_class": "3"})
                    for sw, p, _, b in m.rows]])

    print(f"exporting every {a.interval}s to {'console' if a.console else a.endpoint} "
          f"(source={a.source}, hotspot={a.hotspot}). Ctrl-C to stop.")
    n = 0
    try:
        while True:
            time.sleep(a.interval); m.tick(); n += 1
            if a.count and n >= a.count: break
    except KeyboardInterrupt:
        pass
    reader.force_flush(); metrics.get_meter_provider().shutdown()

if __name__ == "__main__":
    main()
