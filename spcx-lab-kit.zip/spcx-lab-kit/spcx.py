#!/usr/bin/env python3
"""
spcx — Spectrum-X teaching fabric controller (NVIDIA Air substitute).

One tool to build, operate, validate and break a leaf/spine AI fabric that
mirrors the Spectrum-X reference design (rail-optimised, BGP unnumbered,
routed /31 hosts, EVPN multi-tenancy).

Runtimes
  netns : Linux network namespaces + FRR (no Docker needed)   <- default
  clab  : containerlab + FRR containers (image frrouting/frr:v8.4.0)

Usage (run as root):
  ./spcx.py up [--runtime netns|clab]      build the fabric
  ./spcx.py down                           destroy it
  ./spcx.py exec <node> -- <cmd...>        run a shell command on a node
  ./spcx.py vtysh <node> ["<cmd>"]          FRR CLI on a switch
  ./spcx.py show inventory|bgp|routes|lldp  fabric-wide views (NetQ-style)
  ./spcx.py check bgp|interfaces|mtu|reachability|all   validations
  ./spcx.py trace <srcNode> <dstIP>        path trace from a node
  ./spcx.py break <scenario> | list         inject a fault (troubleshooting labs)
  ./spcx.py fix                             restore the intended state
  ./spcx.py evpn on|off                     tenant VRFs RED/BLUE over EVPN-VXLAN
"""
import ipaddress, json, os, shutil, subprocess, sys, time
from pathlib import Path

try:
    import yaml
except ImportError:
    sys.exit("pip install pyyaml  (or: apt install python3-yaml)")

HERE = Path(__file__).resolve().parent
TOPO = yaml.safe_load((HERE / "topology.yaml").read_text())
STATE = Path("/tmp/spcx.state.json")
FRR_BIN = "/usr/lib/frr"
NODES = TOPO["nodes"]
SWITCHES = [n for n, v in NODES.items() if v["role"] in ("leaf", "spine")]
HOSTS = [n for n, v in NODES.items() if v["role"] == "host"]

C = {"g": "\033[32m", "r": "\033[31m", "y": "\033[33m", "b": "\033[1m", "x": "\033[0m"}
def ok(m):   print(f"{C['g']}  PASS{C['x']}  {m}")
def bad(m):  print(f"{C['r']}  FAIL{C['x']}  {m}")
def warn(m): print(f"{C['y']}  WARN{C['x']}  {m}")
def hdr(m):  print(f"\n{C['b']}{m}{C['x']}")

# --------------------------------------------------------------------------- model
# Fabric addressing: "unnumbered" (IPv6 link-local, RFC 5549 — the Spectrum-X RA default)
# or "numbered" (/31 per link). Auto-falls back to numbered if the kernel has no IPv6.
ADDRESSING = os.environ.get("SPCX_ADDRESSING") or (
    "unnumbered" if Path("/proc/sys/net/ipv6").exists() else "numbered")
P2P_POOL = ipaddress.ip_network("172.16.0.0/24")

def links():
    out = []
    p2p = P2P_POOL.subnets(new_prefix=31)
    for l in TOPO["links"]:
        a, b = l[0].split(":"), l[1].split(":")
        out.append({"a": a[0], "ai": a[1], "b": b[0], "bi": b[1],
                    "net": ipaddress.ip_network(l[2]) if len(l) > 2 else None})
        out[-1]["p2p"] = next(p2p) if len(l) == 2 else None
    return out

def p2p_ip(node, l):
    a, b = list(l["p2p"])
    return (a, b) if l["a"] == node else (b, a)   # (mine, peer)

def host_addr(node):
    """Return [(ifname, ip/31, gateway)] for a host."""
    res = []
    for l in links():
        if l["b"] == node and l["net"]:
            h = list(l["net"].hosts()) if l["net"].prefixlen < 31 else list(l["net"])
            res.append((l["bi"], f"{h[1]}/31", str(h[0])))
    return res

# --------------------------------------------------------------------------- config generation
def frr_conf(node):
    v = NODES[node]
    fab = [l["ai"] if l["a"] == node else l["bi"] for l in links()
           if not l["net"] and node in (l["a"], l["b"])]
    hostifs = [(l["ai"], l["net"]) for l in links() if l["a"] == node and l["net"]]
    c = ["frr defaults datacenter", f"hostname {node}", "log syslog informational",
         "service integrated-vtysh-config", "!",
         "interface lo", f" ip address {v['loopback']}/32", "exit", "!"]
    if ADDRESSING == "numbered":
        for l in links():
            if l["p2p"] and node in (l["a"], l["b"]):
                ifn = l["ai"] if l["a"] == node else l["bi"]
                c += [f"interface {ifn}", f" ip address {p2p_ip(node, l)[0]}/31", "exit", "!"]
    for ifn, net in hostifs:
        c += [f"interface {ifn}", f" description host-{ifn}", f" ip address {net[0]}/31", "exit", "!"]
    c += ["ip prefix-list PL_FABRIC seq 10 permit 10.255.0.0/24 ge 32",
          "ip prefix-list PL_FABRIC seq 20 permit 10.10.0.0/16 ge 31",
          "ip prefix-list PL_FABRIC seq 30 permit 10.11.0.0/16 ge 31", "!",
          "route-map RM_CONNECTED permit 10", " match ip address prefix-list PL_FABRIC", "exit", "!",
          f"router bgp {v['asn']}", f" bgp router-id {v['loopback']}",
          " bgp bestpath as-path multipath-relax",
          " neighbor FABRIC peer-group", " neighbor FABRIC remote-as external",
          " neighbor FABRIC timers 3 9"]
    if ADDRESSING == "unnumbered":
        c += [f" neighbor {i} interface peer-group FABRIC" for i in fab]
    else:
        for l in links():
            if l["p2p"] and node in (l["a"], l["b"]):
                c.append(f" neighbor {p2p_ip(node, l)[1]} peer-group FABRIC")
    c += [" address-family ipv4 unicast", "  redistribute connected route-map RM_CONNECTED",
          "  maximum-paths 64", " exit-address-family",
          " address-family l2vpn evpn", "  neighbor FABRIC activate", " exit-address-family",
          "exit", "!"]
    return "\n".join(c) + "\n"

DAEMONS = """zebra=yes
bgpd=yes
ospfd=no
bfdd=yes
vtysh_enable=yes
zebra_options="  -A 127.0.0.1 -s 90000000"
bgpd_options="   -A 127.0.0.1"
bfdd_options="   -A 127.0.0.1"
"""

def gen():
    cfg = HERE / "configs"
    for n in SWITCHES:
        d = cfg / n; d.mkdir(parents=True, exist_ok=True)
        (d / "frr.conf").write_text(frr_conf(n))
        (d / "daemons").write_text(DAEMONS)
        (d / "vtysh.conf").write_text("service integrated-vtysh-config\n")
    # containerlab topology
    clab = {"name": TOPO["name"], "topology": {
        "defaults": {"kind": "linux", "image": "frrouting/frr:v8.4.0"},
        "nodes": {}, "links": []}}
    for n in SWITCHES:
        clab["topology"]["nodes"][n] = {"binds": [
            f"../configs/{n}/frr.conf:/etc/frr/frr.conf",
            f"../configs/{n}/daemons:/etc/frr/daemons",
            f"../configs/{n}/vtysh.conf:/etc/frr/vtysh.conf"],
            "exec": ["sysctl -w net.ipv4.ip_forward=1", "sysctl -w net.ipv6.conf.all.disable_ipv6=0",
                     "sysctl -w net.ipv6.conf.all.forwarding=1"]}
    for n in HOSTS:
        ex = []
        for ifn, ip, gw in host_addr(n):
            ex += [f"ip link set {ifn} mtu {TOPO['mtu_host']}", f"ip addr add {ip} dev {ifn}"]
        ex += host_routes_cmds(n)
        clab["topology"]["nodes"][n] = {"exec": ex}
    for l in links():
        clab["topology"]["links"].append({"endpoints": [f"{l['a']}:{l['ai']}", f"{l['b']}:{l['bi']}"],
                                          "mtu": TOPO["mtu_fabric"]})
    (HERE / "clab").mkdir(exist_ok=True)
    (HERE / "clab" / "spcx.clab.yml").write_text(
        "# generated by ./spcx.py gen — do not edit by hand\n" + yaml.safe_dump(clab, sort_keys=False))
    print(f"generated configs/ for {len(SWITCHES)} switches and clab/spcx.clab.yml")

def host_routes_cmds(n):
    cmds = []
    for ifn, ip, gw in host_addr(n):
        rail_net = "10.10.0.0/16" if ip.startswith("10.10.") else "10.11.0.0/16"
        cmds.append(f"ip route add {rail_net} via {gw} dev {ifn}")
    # loopbacks reachable via rail-0 NIC
    first = host_addr(n)[0]
    cmds.append(f"ip route add 10.255.0.0/24 via {first[2]} dev {first[0]}")
    return cmds

# --------------------------------------------------------------------------- runtime
def state():
    return json.loads(STATE.read_text()) if STATE.exists() else {"runtime": "netns", "faults": []}

def save(s): STATE.write_text(json.dumps(s))

def run(cmd, check=False, quiet=True):
    r = subprocess.run(cmd, shell=isinstance(cmd, str), capture_output=True, text=True)
    if check and r.returncode:
        sys.exit(f"command failed: {cmd}\n{r.stderr}")
    return r.stdout if quiet else r

def nexec(node, cmd):
    """Run a shell command string on a node; return stdout."""
    if state()["runtime"] == "clab":
        return run(["docker", "exec", f"clab-{TOPO['name']}-{node}", "sh", "-c", cmd])
    return run(["ip", "netns", "exec", node, "sh", "-c", cmd])

def vtysh(node, cmd):
    if state()["runtime"] == "clab":
        return run(["docker", "exec", f"clab-{TOPO['name']}-{node}", "vtysh", "-c", cmd])
    return run(["ip", "netns", "exec", node, "vtysh", "-N", node, "-c", cmd])

def vjson(node, cmd):
    out = vtysh(node, cmd + " json")
    try:
        return json.loads(out)
    except json.JSONDecodeError:
        return {}

def up(runtime):
    gen()
    save({"runtime": runtime, "faults": []})
    if runtime == "clab":
        run(f"cd {HERE}/clab && containerlab deploy -t spcx.clab.yml --reconfigure", check=True)
        print("containerlab fabric deployed; waiting 20s for BGP..."); time.sleep(20); return
    if not shutil.which("vtysh"):
        sys.exit("FRR not installed: sudo apt install -y frr")
    for n in NODES:
        run(f"ip netns del {n}"); run(f"ip netns add {n}", check=True)
        nexec(n, "ip link set lo up; sysctl -qw net.ipv4.ip_forward=1; "
                 "sysctl -qw net.ipv6.conf.all.forwarding=1; sysctl -qw net.ipv6.conf.all.disable_ipv6=0; "
                 "sysctl -qw net.ipv4.fib_multipath_hash_policy=1")
    for l in links():
        ta, tb = f"{l['a']}-{l['ai']}"[:15], f"{l['b']}-{l['bi']}"[:15]
        run(f"ip link add {ta} type veth peer name {tb}", check=True)
        run(f"ip link set {ta} netns {l['a']}"); run(f"ip link set {tb} netns {l['b']}")
        for node, tmp, ifn in ((l["a"], ta, l["ai"]), (l["b"], tb, l["bi"])):
            mtu = TOPO["mtu_host"] if NODES[node]["role"] == "host" else TOPO["mtu_fabric"]
            nexec(node, f"ip link set {tmp} name {ifn}; ip link set {ifn} mtu {mtu} up")
    for n in HOSTS:
        for ifn, ip, gw in host_addr(n):
            nexec(n, f"ip addr add {ip} dev {ifn}")
        for c in host_routes_cmds(n):
            nexec(n, c)
    for n in SWITCHES:
        etc, rund = Path(f"/etc/frr/{n}"), Path(f"/var/run/frr/{n}")
        etc.mkdir(parents=True, exist_ok=True); rund.mkdir(parents=True, exist_ok=True)
        for f in ("frr.conf", "vtysh.conf", "daemons"):
            shutil.copy(HERE / "configs" / n / f, etc / f)
        run(f"chown -R frr:frr {etc} {rund}")
        for d in ("zebra", "bfdd", "bgpd"):
            nexec(n, f"{FRR_BIN}/{d} -d -N {n} -F datacenter -A 127.0.0.1")
        time.sleep(0.3)
        nexec(n, f"vtysh -N {n} -b")
    print(f"fabric addressing: {ADDRESSING}")
    print(f"netns fabric up: {len(SWITCHES)} switches, {len(HOSTS)} hosts. Waiting 15s for BGP...")
    time.sleep(15)
    check("bgp")

def down():
    s = state()
    if s["runtime"] == "clab":
        run(f"cd {HERE}/clab && containerlab destroy -t spcx.clab.yml --cleanup")
    else:
        for n in SWITCHES:
            for d in ("bgpd", "bfdd", "zebra"):
                pf = Path(f"/var/run/frr/{n}/{d}.pid")
                if pf.exists():
                    run(f"kill {pf.read_text().strip()}")
        for n in NODES:
            run(f"ip netns del {n}")
    STATE.unlink(missing_ok=True)
    print("fabric destroyed")

# --------------------------------------------------------------------------- NetQ-style views
def show(what):
    if what == "inventory":
        hdr(f"{'node':8} {'role':6} {'asn':6} {'loopback':13} rail su")
        for n, v in NODES.items():
            print(f"{n:8} {v['role']:6} {str(v.get('asn','-')):6} {v.get('loopback','-'):13} "
                  f"{str(v.get('rail','-')):4} {v.get('su','-')}")
    elif what == "bgp":
        hdr(f"{'switch':8} {'peer':12} {'remote-as':9} {'state':12} {'pfx-rcvd':8} uptime")
        for n in SWITCHES:
            peers = vjson(n, "show bgp ipv4 unicast summary").get("peers", {})
            for p, d in peers.items():
                print(f"{n:8} {p:12} {str(d.get('remoteAs')):9} {d.get('state'):12} "
                      f"{str(d.get('pfxRcd', '-')):8} {d.get('peerUptime')}")
    elif what == "routes":
        for n in SWITCHES:
            hdr(n); print(vtysh(n, "show ip route bgp").split("\n\n", 1)[-1])
    elif what == "lldp":
        hdr("cabling plan (intended)")
        for l in links():
            print(f"  {l['a']}:{l['ai']:5} <-> {l['b']}:{l['bi']}")

def check(what):
    fails = 0
    if what in ("bgp", "all"):
        hdr("check bgp — every fabric session Established, prefixes exchanged")
        for n in SWITCHES:
            peers = vjson(n, "show bgp ipv4 unicast summary").get("peers", {})
            if not peers:
                bad(f"{n}: BGP not running / no peers"); fails += 1; continue
            for p, d in peers.items():
                if d.get("state") != "Established":
                    bad(f"{n} -> {p}: {d.get('state')}"); fails += 1
                elif not d.get("pfxRcd"):
                    warn(f"{n} -> {p}: Established but 0 prefixes received")
            if all(d.get("state") == "Established" for d in peers.values()):
                ok(f"{n}: {len(peers)}/{len(peers)} sessions Established")
    if what in ("interfaces", "all"):
        hdr("check interfaces — every cabled port is admin+oper UP")
        for l in links():
            for node, ifn in ((l["a"], l["ai"]), (l["b"], l["bi"])):
                j = json.loads(nexec(node, f"ip -j link show {ifn}") or "[{}]")[0]
                if "UP" not in j.get("flags", []) or j.get("operstate") not in ("UP", "UNKNOWN"):
                    bad(f"{node}:{ifn} is {j.get('operstate','missing')}"); fails += 1
        if not fails: ok("all cabled interfaces up")
    if what in ("mtu", "all"):
        hdr("check mtu — both ends of each link agree")
        mfail = 0
        for l in links():
            ma = json.loads(nexec(l["a"], f"ip -j link show {l['ai']}") or "[{}]")[0].get("mtu")
            mb = json.loads(nexec(l["b"], f"ip -j link show {l['bi']}") or "[{}]")[0].get("mtu")
            hostlink = l["net"] is not None
            if not hostlink and ma != mb:
                bad(f"{l['a']}:{l['ai']}={ma} vs {l['b']}:{l['bi']}={mb}"); mfail += 1
            if hostlink and (mb or 0) > (ma or 0):
                bad(f"host {l['b']}:{l['bi']} mtu {mb} > switch {l['a']}:{l['ai']} {ma}"); mfail += 1
        fails += mfail
        if not mfail: ok("MTU consistent across all links")
    if what in ("reachability", "all"):
        hdr("check reachability — every NIC reaches every same-rail NIC with jumbo frames")
        nics = {n: host_addr(n) for n in HOSTS}
        for src in HOSTS:
            for dst in HOSTS:
                if src == dst: continue
                for (sif, sip, _), (dif, dip, _) in zip(nics[src], nics[dst]):
                    tgt = dip.split("/")[0]
                    r = nexec(src, f"ping -c1 -W1 -M do -s 8972 -I {sip.split('/')[0]} {tgt} >/dev/null && echo y")
                    if "y" not in r:
                        bad(f"{src}:{sif} -> {dst} {tgt} (jumbo 9000)"); fails += 1
        if not fails: ok("full same-rail reachability with 9000-byte frames")
    hdr(f"RESULT: {'ALL CHECKS PASSED' if not fails else f'{fails} failure(s)'}")
    return fails

def trace(src, dst):
    print(nexec(src, f"traceroute -n -q1 -w1 {dst} 2>/dev/null || tracepath -n {dst}"))

# --------------------------------------------------------------------------- fault injection
FAULTS = {
    "mtu":       ("leaf3 uplink to spine1 drops to MTU 1500",
                  lambda: nexec("leaf3", "ip link set eth1 mtu 1500"),
                  lambda: nexec("leaf3", f"ip link set eth1 mtu {TOPO['mtu_fabric']}")),
    "link":      ("cable pull: spine2 port to leaf2",
                  lambda: nexec("spine2", "ip link set eth2 down"),
                  lambda: nexec("spine2", "ip link set eth2 up")),
    "bgp-shut":  ("leaf4 administratively shuts its spine1 session",
                  lambda: vtysh("leaf4", f"conf t\nrouter bgp 65104\nneighbor {nbr('leaf4','eth1')} shutdown"),
                  lambda: vtysh("leaf4", f"conf t\nrouter bgp 65104\nno neighbor {nbr('leaf4','eth1')} shutdown")),
    "asn":       ("leaf1 mis-provisioned: spine1 expected to be AS 65199",
                  lambda: vtysh("leaf1", f"conf t\nrouter bgp 65101\nno neighbor {nbr('leaf1','eth1')}\n"
                                        f"neighbor {nbr('leaf1','eth1')} {'interface ' if ADDRESSING == 'unnumbered' else ''}remote-as 65199"),
                  lambda: vtysh("leaf1", f"conf t\nrouter bgp 65101\nno neighbor {nbr('leaf1','eth1')}\n"
                                        f"neighbor {nbr('leaf1','eth1')} {'interface ' if ADDRESSING == 'unnumbered' else ''}peer-group FABRIC")),
    "prefix":    ("leaf3 stops advertising rail-0 host subnets (bad prefix-list edit)",
                  lambda: vtysh("leaf3", "conf t\nno ip prefix-list PL_FABRIC seq 20"),
                  lambda: vtysh("leaf3", "conf t\nip prefix-list PL_FABRIC seq 20 permit 10.10.0.0/16 ge 31")),
    "host-mtu":  ("srv2 NIC eth1 set to MTU 9216 (bigger than the switch port)",
                  lambda: (nexec("leaf1", "ip link set eth4 mtu 9000"), nexec("srv2", "ip link set eth1 mtu 9216")),
                  lambda: (nexec("leaf1", f"ip link set eth4 mtu {TOPO['mtu_fabric']}"),
                           nexec("srv2", f"ip link set eth1 mtu {TOPO['mtu_host']}"))),
}

def nbr(node, ifn):
    """BGP neighbor name for a fabric port (interface in unnumbered, peer IP in numbered)."""
    if ADDRESSING == "unnumbered": return ifn
    for l in links():
        if l["p2p"] and ((l["a"], l["ai"]) == (node, ifn) or (l["b"], l["bi"]) == (node, ifn)):
            return str(p2p_ip(node, l)[1])

def brk(name):
    if name == "list" or name not in FAULTS:
        for k, v in FAULTS.items(): print(f"  {k:9} {v[0] if name == 'reveal' else '(hidden symptom)'}")
        return
    s = state(); FAULTS[name][1](); s["faults"].append(name); save(s)
    print(f"fault '{name}' injected. Use 'check all', 'show bgp', 'trace' to find it.")

def fix():
    s = state()
    for f in reversed(s["faults"]): FAULTS[f][2]()
    for n in NODES: nexec(n, "ip route flush cache")   # drop learned path-MTU entries
    s["faults"] = []; save(s); print("all injected faults reverted (route/PMTU caches flushed)")

# --------------------------------------------------------------------------- EVPN multi-tenancy
TENANTS = {"RED": (4001, 1001, {"leaf1": "eth3", "leaf3": "eth3"}),
           "BLUE": (4002, 1002, {"leaf1": "eth4", "leaf3": "eth4"})}

def evpn(onoff):
    if onoff == "on" and "Unknown device type" in nexec("leaf1", "ip link add spcxtest type vrf table 9 2>&1; ip link del spcxtest 2>/dev/null"):
        sys.exit("kernel has no VRF support (CONFIG_NET_VRF). Use a standard Ubuntu 22.04/24.04 VM for Lab 3.")
    for vrf, (vni, table, members) in TENANTS.items():
        for leaf, port in members.items():
            lo, asn = NODES[leaf]["loopback"], NODES[leaf]["asn"]
            if onoff == "on":
                nexec(leaf, f"""
                  ip link add {vrf} type vrf table {table}; ip link set {vrf} up
                  ip link set {port} master {vrf}
                  ip link add br{vni} type bridge; ip link set br{vni} master {vrf} addrgenmode none
                  ip link add vx{vni} type vxlan local {lo} dstport 4789 id {vni} nolearning
                  ip link set vx{vni} master br{vni} addrgenmode none
                  ip link set vx{vni} type bridge_slave neigh_suppress on learning off
                  ip link set vx{vni} up; ip link set br{vni} up""")
                # kernel keeps the /31 on the port when it is enslaved to the VRF
                vtysh(leaf, f"conf t\nvrf {vrf}\nvni {vni}\nexit-vrf\n"
                            f"router bgp {asn}\naddress-family l2vpn evpn\nadvertise-all-vni\nexit-address-family\nexit\n"
                            f"router bgp {asn} vrf {vrf}\nbgp router-id {lo}\n"
                            f"address-family ipv4 unicast\nredistribute connected\nexit-address-family\n"
                            f"address-family l2vpn evpn\nadvertise ipv4 unicast\n"
                            f"route-target import 65000:{vni}\nroute-target export 65000:{vni}\nexit-address-family")
            else:
                vtysh(leaf, f"conf t\nno router bgp {asn} vrf {vrf}\nvrf {vrf}\nno vni {vni}\nexit-vrf")
                nexec(leaf, f"ip link set {port} nomaster; ip link del vx{vni}; ip link del br{vni}; ip link del {vrf}")
    print(f"EVPN tenants {onoff}. Try: ./spcx.py vtysh leaf1 'show bgp l2vpn evpn route type prefix'")

# --------------------------------------------------------------------------- CLI
def main(a):
    if not a or a[0] in ("-h", "--help"): print(__doc__); return
    cmd = a[0]
    if cmd == "gen": gen()
    elif cmd == "up": up(a[2] if len(a) > 2 and a[1] == "--runtime" else "netns")
    elif cmd == "down": down()
    elif cmd == "exec": print(nexec(a[1], " ".join(a[3:] if a[2:3] == ["--"] else a[2:])), end="")
    elif cmd == "vtysh":
        if len(a) > 2: print(vtysh(a[1], a[2]), end="")
        elif state()["runtime"] == "clab": os.execvp("docker", ["docker", "exec", "-it", f"clab-{TOPO['name']}-{a[1]}", "vtysh"])
        else: os.execvp("ip", ["ip", "netns", "exec", a[1], "vtysh", "-N", a[1]])
    elif cmd == "show": show(a[1])
    elif cmd == "check": sys.exit(1 if check(a[1] if len(a) > 1 else "all") else 0)
    elif cmd == "trace": trace(a[1], a[2])
    elif cmd == "break": brk(a[1] if len(a) > 1 else "list")
    elif cmd == "fix": fix()
    elif cmd == "evpn": evpn(a[1])
    else: print(__doc__)

if __name__ == "__main__":
    main(sys.argv[1:])
